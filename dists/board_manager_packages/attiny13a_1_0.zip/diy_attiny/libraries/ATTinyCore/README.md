This is a dummy library so we can get some examples into File>Examples>ATTinyCore

Unfortunatly there doesn't seem to be a better way to have examples for a core currently.

https://github.com/arduino/Arduino/issues/4187